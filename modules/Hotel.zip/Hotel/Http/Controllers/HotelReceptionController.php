<?php

namespace Modules\Hotel\Http\Controllers;

use Illuminate\Routing\Controller;
use Modules\Hotel\Models\HotelRoom;
use Modules\Hotel\Models\HotelFloor;
use Modules\Hotel\Models\HotelRent;
use Modules\Hotel\Models\HotelRentChange;
use Illuminate\Http\Request;
use App\Models\Tenant\Establishment;
use App\Models\Tenant\User;
use Carbon\Carbon;
use DB;

class HotelReceptionController extends Controller
{
	public function index()
	{
		$rooms = $this->getRooms();

		if (request()->ajax()) {
			return response()->json([
				'success' => true,
				'rooms'   => $rooms,
			], 200);
		}
		$floors = HotelFloor::where('active', true)
                ->where('establishment_id',auth()->user()->establishment_id)
				->orderBy('description')
				->get();

		$roomStatus = HotelRoom::$status;

        $userType = auth()->user()->type;
		$establishmentId = auth()->user()->establishment_id;
        $establishments = Establishment::select('id','description')->get();

		return view('hotel::rooms.reception', compact('rooms', 'floors', 'roomStatus','userType','establishmentId','establishments'));
	}

    /**
     * Busqueda avanzada de cuartos.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function  searchRooms(Request $request ){

        $user = auth()->user();
        $rooms = HotelRoom::with('category', 'floor', 'rates')
            ->where('establishment_id', $user->establishment_id);

        // Si el usuario es limpiador, solo mostrar habitaciones asignadas para limpiar
        if ($user->type === 'limpiador') {
            $roomIdsForCleaning = \App\Models\Tenant\HotelCleaning::where('user_id', $user->id)
                ->whereIn('status', ['pending', 'in_progress'])
                ->pluck('hotel_room_id')
                ->toArray();
            
            $rooms->whereIn('id', $roomIdsForCleaning);
        }

        if ($request->has('hotel_floor_id') && !empty($request->hotel_floor_id)) {
            $rooms->where('hotel_floor_id', $request->hotel_floor_id);
        }
        if ($request->has('hotel_status_room') && !empty($request->hotel_status_room)) {
            $rooms->where('status',  $request->hotel_status_room);
        }
        if ($request->has('hotel_name_room') && !empty($request->hotel_name_room)) {
            $rooms->where('name','LIKE',  "%{$request->hotel_name_room}%");
        }
        $rooms = $rooms->orderBy('name')->get()->each(function ($room) {
            // Buscar rent activo (reserva o renta normal)
            $rent = HotelRent::with('customer.person_type')->where('hotel_room_id', $room->id)
                ->orderBy('id', 'DESC')
                ->first();
            
            if ($rent) {
                $room->rent = $rent;
                
                // Si es una reserva, verificar si ya llegó la fecha de ingreso
                if ($rent->is_reserve) {
                    $now = \Carbon\Carbon::now();
                    $inputTime = $rent->input_time ?? '12:00:00';
                    
                    // Validar que tengamos datos de fecha
                    if (!$rent->input_date) {
                        \Log::error('Fecha de input_date es nula para la reserva: ' . $rent->id);
                        $room->status = 'DISPONIBLE';
                        $room->has_reservation = true;
                        return $room;
                    }
                    
                    try {
                        $inputDateTime = \Carbon\Carbon::createFromFormat(
                            'Y-m-d H:i:s', 
                            $rent->input_date . ' ' . $inputTime
                        );
                    } catch (\Exception $e) {
                        \Log::error('Error al crear fecha desde formato: ' . $e->getMessage());
                        \Log::error('Datos: input_date=' . $rent->input_date . ', input_time=' . $inputTime);
                        // En caso de error, asumir que la fecha es válida
                        $inputDateTime = \Carbon\Carbon::parse($rent->input_date);
                    }
                    
                    // Si la fecha de ingreso aún no llega, mantener la habitación como disponible
                    if ($inputDateTime->gt($now)) {
                        $room->status = 'DISPONIBLE';
                        $room->has_reservation = true; // Marcar que tiene reserva
                    } else {
                        // Si ya llegó la fecha, mostrar como disponible para check-in
                        $room->status = 'DISPONIBLE';
                        $room->ready_for_checkin = true; // Lista para check-in
                        $room->has_reservation = true;
                    }
                }
            } else {
                $room->rent = [];
                $room->has_reservation = false;
                $room->ready_for_checkin = false;
            }

            // Buscar reservas futuras para esta habitación (solo si está ocupada actualmente)
            if ($room->status === 'OCUPADO') {
                $futureReservation = HotelRent::with('customer.person_type')
                    ->where('hotel_room_id', $room->id)
                    ->where('is_reserve', true)
                    ->where('input_date', '>', \Carbon\Carbon::now()->format('Y-m-d'))
                    ->orderBy('input_date', 'ASC')
                    ->first();
                
                if ($futureReservation) {
                    $room->has_future_reservation = true;
                    $room->future_reservation = $futureReservation;
                } else {
                    $room->has_future_reservation = false;
                    $room->future_reservation = null;
                }
            } else {
                $room->has_future_reservation = false;
                $room->future_reservation = null;
            }

            // Determinar si tiene limpiador asignado
            if ($room->status === 'LIMPIEZA') {
                $cleaning = \App\Models\Tenant\HotelCleaning::where('hotel_room_id', $room->id)
                    ->whereIn('status', ['pending', 'in_progress'])
                    ->first();
                $room->has_cleaner_assigned = $cleaning && $cleaning->user_id !== null;
            } else {
                $room->has_cleaner_assigned = false;
            }

            return $room;
        });

        return response()->json([
            'success' => true,
            'rooms'   => $rooms,
        ], 200);
    }
    /**
     * Devuelve informacion de cuartos disponibles
     *
     * @return \Illuminate\Database\Eloquent\Builder[]|\Illuminate\Database\Eloquent\Collection|\Illuminate\Support\Collection|\Modules\Hotel\Models\HotelRoom[]
     */
    private function getRooms()
    {
        $user = auth()->user();
        $rooms = HotelRoom::with('category', 'floor', 'rates', 'establishment')
            ->where('establishment_id', $user->establishment_id);

        // Si el usuario es limpiador, solo mostrar habitaciones asignadas para limpiar
        if ($user->type === 'limpiador') {
            $roomIdsForCleaning = \App\Models\Tenant\HotelCleaning::where('user_id', $user->id)
                ->whereIn('status', ['pending', 'in_progress'])
                ->pluck('hotel_room_id')
                ->toArray();
            
            $rooms->whereIn('id', $roomIdsForCleaning);
        }

        if (request('hotel_floor_id')) {
            $rooms->where('hotel_floor_id', request('hotel_floor_id'));
        }
        if (request('status')) {
            $rooms->where('status', request('status'));
        }

        $rooms->orderBy('name');
        return $rooms->get()->each(function ($room) {
            // Buscar rent activo (reserva o renta normal)
            $rent = HotelRent::with('items', 'customer.person_type')->where('hotel_room_id', $room->id)
                ->orderBy('id', 'DESC')
                ->first();
            
            if ($rent) {
                $room->rent = $rent;
                
                // Si es una reserva, verificar si ya llegó la fecha de ingreso
                if ($rent->is_reserve) {
                    $now = \Carbon\Carbon::now();
                    $inputTime = $rent->input_time ?? '12:00:00';
                    
                    // Validar que tengamos datos de fecha
                    if (!$rent->input_date) {
                        \Log::error('Fecha de input_date es nula para la reserva: ' . $rent->id);
                        $room->status = 'DISPONIBLE';
                        $room->has_reservation = true;
                        return $room;
                    }
                    
                    try {
                        $inputDateTime = \Carbon\Carbon::createFromFormat(
                            'Y-m-d H:i:s', 
                            $rent->input_date . ' ' . $inputTime
                        );
                    } catch (\Exception $e) {
                        \Log::error('Error al crear fecha desde formato: ' . $e->getMessage());
                        \Log::error('Datos: input_date=' . $rent->input_date . ', input_time=' . $inputTime);
                        // En caso de error, asumir que la fecha es válida
                        $inputDateTime = \Carbon\Carbon::parse($rent->input_date);
                    }
                    
                    // Si la fecha de ingreso aún no llega, mantener la habitación como disponible
                    if ($inputDateTime->gt($now)) {
                        $room->status = 'DISPONIBLE';
                        $room->has_reservation = true; // Marcar que tiene reserva
                    } else {
                        // Si ya llegó la fecha, mostrar como disponible para check-in
                        $room->status = 'DISPONIBLE';
                        $room->ready_for_checkin = true; // Lista para check-in
                        $room->has_reservation = true;
                    }
                }
            } else {
                $room->rent = [];
                $room->has_reservation = false;
                $room->ready_for_checkin = false;
            }

            // Determinar si tiene limpiador asignado
            if ($room->status === 'LIMPIEZA') {
                $cleaning = \App\Models\Tenant\HotelCleaning::where('hotel_room_id', $room->id)
                    ->whereIn('status', ['pending', 'in_progress'])
                    ->first();
                $room->has_cleaner_assigned = $cleaning && $cleaning->user_id !== null;
            } else {
                $room->has_cleaner_assigned = false;
            }

            return $room;
        });
    }

    public function getItem($id)
    {
        $rent = HotelRent::findOrFail($id);

        // Cargar todos los items del rent, no solo los de tipo HAB
        $items = $rent->items;
        
        $item = $items->where('type', 'HAB')->where('payment_status', 'PAID')->first();
        $item_debt = $items->where('type', 'HAB')->where('payment_status', 'DEBT')->first();

        return response()->json([
            'success' => true,
            'data' => [
                'rent' => $rent,
                'items' => $items, // Agregar todos los items
                'item' => $item,
                'item_debt' => $item_debt
            ],
            'message'   => "Datos encontrados",
        ], 200);
    }

    public function changeUserEstablishment(Request $request)
    {
        $user = User::findOrFail(auth()->user()->id);
        $user->establishment_id = $request->establishment_id;
        $user->save();

        return response()->json([
            'success' => true,
            'message'   => "Establecimiento actualizado con éxito",
        ], 200);
    }

    /**
     * Obtener habitaciones disponibles para cambio
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function getAvailableRooms()
    {
        $rooms = HotelRoom::with('category', 'floor')
            ->where('establishment_id', auth()->user()->establishment_id)
            ->where('status', 'DISPONIBLE')
            ->where('active', true)
            ->orderBy('name')
            ->get();

        return response()->json([
            'success' => true,
            'rooms' => $rooms,
            'message' => 'Habitaciones disponibles obtenidas correctamente'
        ], 200);
    }

    /**
     * Editar fechas de check-in/check-out
     *
     * @param int $id
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function editDates($id, Request $request)
    {
        try {
            DB::beginTransaction();

            $rent = HotelRent::with(['room', 'items'])->findOrFail($id);
            
            // Validar que el rent no esté finalizado
            if ($rent->status === 'FINALIZADO') {
                return response()->json([
                    'success' => false,
                    'message' => 'No se puede editar fechas de un alquiler finalizado'
                ], 400);
            }

            $editInput = $request->input('edit_input', false);
            $editOutput = $request->input('edit_output', false);
            $inputDate = $request->input('input_date');
            $inputTime = $request->input('input_time', '12:00');
            $outputDate = $request->input('output_date');
            $outputTime = $request->input('output_time', '11:59');
            $newPrice = $request->input('new_price');

            // Validar fechas
            $inputDateTime = Carbon::parse("{$inputDate} {$inputTime}");
            $outputDateTime = Carbon::parse("{$outputDate} {$outputTime}");

            if (!$inputDateTime->lt($outputDateTime)) {
                return response()->json([
                    'success' => false,
                    'message' => 'La fecha de salida debe ser posterior a la fecha de ingreso'
                ], 400);
            }

            // Guardar valores originales para el historial
            $oldValues = [
                'input_date' => $rent->input_date,
                'input_time' => $rent->input_time,
                'output_date' => $rent->output_date,
                'output_time' => $rent->output_time
            ];

            // Actualizar fechas
            if ($editInput) {
                $rent->input_date = $inputDate;
                $rent->input_time = $inputTime;
            }
            if ($editOutput) {
                $rent->output_date = $outputDate;
                $rent->output_time = $outputTime;
            }

            // Actualizar precio si se proporciona
            $newItemPrice = null;
            if ($newPrice !== null && $newPrice > 0) {
                $roomItem = $rent->items()->where('type', 'HAB')->first();
                if ($roomItem) {
                    $oldTotal = $roomItem->total;
                    $roomItem->total = $newPrice;
                    
                    // Recalcular unit_price basado en la duración
                    $duration = $inputDateTime->diffInDays($outputDateTime);
                    $unitPrice = $duration > 0 ? $newPrice / $duration : $newPrice;
                    $roomItem->unit_price = $unitPrice;
                    $roomItem->save();

                    $newItemPrice = [
                        'unit_price' => $unitPrice,
                        'total' => $newPrice
                    ];
                }
            }

            $rent->save();

            // Registrar cambio en el historial
            $this->recordChange($rent, 'DATE_EDIT', $oldValues, [
                'input_date' => $editInput ? $inputDate : $rent->input_date,
                'input_time' => $editInput ? $inputTime : $rent->input_time,
                'output_date' => $editOutput ? $outputDate : $rent->output_date,
                'output_time' => $editOutput ? $outputTime : $rent->output_time
            ], $editInput ? 'Edición de fecha de ingreso' : 'Edición de fecha de salida', $request->input('price_difference', 0));

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Fechas actualizadas correctamente',
                'rent' => $rent->fresh(['room', 'customer']),
                'new_item_price' => $newItemPrice
            ], 200);

        } catch (\Exception $e) {
            DB::rollBack();
            
            return response()->json([
                'success' => false,
                'message' => 'Error al actualizar las fechas: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Obtener historial de cambios de una habitación
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function getRoomHistory($id)
    {
        try {
            $rent = HotelRent::findOrFail($id);
            
            $history = HotelRentChange::with('user')
                ->where('hotel_rent_id', $id)
                ->orderBy('created_at', 'desc')
                ->get();

            return response()->json([
                'success' => true,
                'history' => $history,
                'message' => 'Historial obtenido correctamente'
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener el historial: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Registrar un cambio en el historial
     *
     * @param HotelRent $rent
     * @param string $changeType
     * @param array $oldValues
     * @param array $newValues
     * @param string|null $notes
     * @param float $priceDifference
     * @return HotelRentChange
     */
    private function recordChange($rent, $changeType, $oldValues, $newValues, $notes = null, $priceDifference = 0)
    {
        return HotelRentChange::create([
            'hotel_rent_id' => $rent->id,
            'change_type' => $changeType,
            'old_values' => $oldValues,
            'new_values' => $newValues,
            'notes' => $notes,
            'price_difference' => $priceDifference,
            'user_id' => auth()->id()
        ]);
    }

    /**
     * Obtener datos actualizados de una habitación específica
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function getRoom($id)
    {
        try {
            $user = auth()->user();
            $room = HotelRoom::with('category', 'floor', 'rates', 'establishment')
                ->where('establishment_id', $user->establishment_id)
                ->where('id', $id)
                ->first();

            if (!$room) {
                return response()->json([
                    'success' => false,
                    'message' => 'Habitación no encontrada'
                ], 404);
            }

            // Aplicar la misma lógica que en getRooms() para determinar has_cleaner_assigned
            if ($room->status === 'LIMPIEZA') {
                $cleaning = \App\Models\Tenant\HotelCleaning::where('hotel_room_id', $room->id)
                    ->whereIn('status', ['pending', 'in_progress'])
                    ->first();
                $room->has_cleaner_assigned = $cleaning && $cleaning->user_id !== null;
            } else {
                $room->has_cleaner_assigned = false;
            }

            return response()->json([
                'success' => true,
                'room' => $room
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al obtener la habitación: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Endpoint público para registrar cambios (usado por el frontend)
     *
     * @param int $id
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function recordChangePublic($id, Request $request)
    {
        try {
            $rent = HotelRent::findOrFail($id);
            
            $change = $this->recordChange(
                $rent,
                $request->input('change_type'),
                $request->input('old_values', []),
                $request->input('new_values', []),
                $request->input('notes'),
                $request->input('price_difference', 0)
            );

            return response()->json([
                'success' => true,
                'message' => 'Cambio registrado correctamente',
                'change' => $change
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error al registrar el cambio: ' . $e->getMessage()
            ], 500);
        }
    }
}
