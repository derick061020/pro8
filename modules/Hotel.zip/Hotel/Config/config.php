<?php

return [
    'name' => 'Hotel'
];
